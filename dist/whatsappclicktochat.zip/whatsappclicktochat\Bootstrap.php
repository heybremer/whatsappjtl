<?php
namespace Plugin\whatsappclicktochat;

class Bootstrap
{
	public function installed(): bool
	{
		return true;
	}

	public function enabled(): bool
	{
		return true;
	}

	public function disabled(): bool
	{
		return true;
	}
}


