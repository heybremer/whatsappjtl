# Değişiklik Günlüğü

## 1.0.1 - 2025-10-06
- Dağıtım arşivini depodan kaldırarak PR oluşturma hatasını önle.

## 1.0.0 - 2025-10-06
- İlk sürüm: WhatsApp hızlı sohbet butonu, yapılandırılabilir mesaj ve durum seçenekleri.
