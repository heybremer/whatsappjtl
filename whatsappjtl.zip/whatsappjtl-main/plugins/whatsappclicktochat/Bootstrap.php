<?php

declare(strict_types=1);

namespace Plugin\whatsappclicktochat;

use JTL\Plugin\Bootstrapper;

/**
 * Standart JTL bootstrap sınıfı.
 */
class Bootstrap extends Bootstrapper
{
}
